﻿namespace CustomIdentity.Views.Account
{
    public class Index
    {
    }
}
